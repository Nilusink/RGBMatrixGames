# Wave Pattern

Demo of the colours, and the little flicker.

![It's better in real life](PatternWave.jpg)
